import telebot
import time
from datetime import datetime
from bs4 import BeautifulSoup
from urllib.request import urlopen, Request
import threading
from random import randint

TOKEN = '6793630195:AAHx_qd7-G9Xkb1QHrOoDuLmoYFvhoI7VEg'
bot = telebot.TeleBot(token=TOKEN)
running_chat_ids = set()
lock = threading.Lock()
chat_stop_flags = {}
global_stop_flag = False

def parse_html(url):
    while True:
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
            req = Request(url, headers=headers)
            response = urlopen(req)
            html_content = response.read()
            soup = BeautifulSoup(html_content, 'html.parser')

            products = []

            for div in soup.find_all('div', {'class': 'dl', 'id': None}):
                if not div.find_parents('div', {'id': 'tp'}):
                    for a in div.find_all('a', href=True):
                        price_div = a.find('div', {'class': 'p'})
                        div_elements = a.find_all('div')
                        if len(div_elements) >= 3 and price_div:
                            product_name = div_elements[1].text.strip()
                            price = price_div.text.strip()
                            link = a['href']
                            full_link = f"list.am{link}"
                            products.append((product_name, price, full_link))
            return products

        except Exception as e:
            print(f"Error with parsing html data: {e}")
            print(f'Trying again in 5 seconds later'); time.sleep(5)
            continue

def send_updates(chat_id, url):
    global global_stop_flag  # Access the global stop flag
    while not global_stop_flag and not chat_stop_flags.get(chat_id, False):
        product_list = parse_html(url)
        if product_list:
            last_content = product_list[0][2]
            print(f'Printing first last content - {" - ".join(product_list[0])}\n')
            time.sleep(15)
        else:
            time.sleep(15)

        while True:
            if chat_stop_flags.get(chat_id, False):
                break
            product_list2 = parse_html(url)
            if product_list2:
                if product_list2[0][2] == last_content:
                    print(f'{datetime.now().strftime("%H:%M")} - No changes')
                    print(f'Last content - {" - ".join(product_list2[0])}')
                    print(f'Users in chat: {len(running_chat_ids)}, Chat IDs: {", ".join(str(chat_id) for chat_id in running_chat_ids)}\n')
                    time.sleep(randint(55, 88))
                else:
                    i = 1
                    new_data_list = [product_list2[0]]
                    while True:
                        if product_list2[i][2] == last_content:
                            for a in range(len(new_data_list)):
                                print(f'{datetime.now().strftime("%H:%M")} NEW content - {" - ".join(new_data_list[a])}\n')
                                bot.send_message(chat_id, ' - '.join(new_data_list[a]))
                            break
                        else:
                            new_data_list.append(product_list2[i])
                            i += 1                
                    last_content = new_data_list[0][2]
                    print(f'Users in chat: {len(running_chat_ids)}, Chat IDs: {", ".join(str(chat_id) for chat_id in running_chat_ids)}')
                    time.sleep(randint(55, 88))
            else:
                time.sleep(randint(100, 200))


@bot.message_handler(commands=['command1', 'start'])
def send_welcome(message):
    chat_id = message.chat.id
    if chat_id in running_chat_ids:
        bot.reply_to(message, "Kodd ashxatuma spasi!")
    else:
        running_chat_ids.add(chat_id)
        bot.reply_to(message, f'Privet {message.from_user.first_name} jan, listi url-n uxarki vor nor baner@ hetevenq')
        print(f'{message.from_user.first_name} entered to chat')


@bot.message_handler(func=lambda message: message.text.startswith('http'))
def handle_url(message):
    chat_id = message.chat.id
    url = message.text
    if chat_id in running_chat_ids:
        bot.reply_to(message, f'Staca, mna kapi mej, kuxarkem nor baner@')
        chat_stop_flags[chat_id] = False
        threading.Thread(target=send_updates, args=(chat_id, url,)).start()


@bot.message_handler(commands=['stop'])
def stop_updates(message):
    chat_id = message.chat.id
    chat_stop_flags[chat_id] = True
    bot.reply_to(message, "Updates stopped.")
    global global_stop_flag  # Access the global stop flag
    global_stop_flag = True  # Set the global stop flag

@bot.message_handler(content_types=['left_chat_member', 'new_chat_member'])
def chat_membership_change(message):
    chat_id = message.chat.id
    user_name = message.left_chat_member.first_name if 'left_chat_member' in message.json else message.new_chat_member.first_name
    if chat_id in running_chat_ids:
        running_chat_ids.remove(chat_id)
        print(f"Removed user {user_name} from chat.")

# Start the bot
bot.polling(non_stop=True)
